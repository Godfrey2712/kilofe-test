=== E2Pdf - Export To Pdf Tool for WordPress ===
Contributors: rasmarcus, oleksandrz
Donate link: https://e2pdf.com/
Tags: e2pdf, pro2pdf, pdf, create, edit, export, save, generation, pdftk, formidable, caldera, divi, forminator, forms, pdf viewer, create pdf, export pdf, save pdf, formidable pdf, caldera pdf, divi pdf, forminator pdf, forms pdf, wordpress pdf, pdf editor, export to pdf, export data, gravity, gravity pdf
Requires at least: 4.0
Tested up to: 5.7
Requires PHP: 5.3
Stable tag: 1.15.00
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Create and fill dynamic PDF documents with Formidable Forms, Gravity Forms, Caldera Forms, Forminator, Divi, Pages/Posts data, ACF and more...

== Description ==

= E2Pdf is the next generation PDF tool for Wordpress. =

This plugin includes:

* a PDF Document Viewer - Allow visitors to view static or dynamic PDF documents in Wordpress.
* a PDF Document Editor - Create/Edit new and existing PDF documents without leaving Wordpress.
* a PDF Forms Editor - Create/Edit new, existing, and auto-generated PDF Forms from the Dashboard.
* a PDF Data Injector - Merge data from Wordpress pages, posts, or web forms into PDF forms.
* a Generous Affiliate Program - 90-day cookies. 20% commission paid lifetime for all new payments.

= Learn all about E2Pdf =

* [FAQ](https://e2pdf.com/support/faq)
* [Help Desk](https://e2pdf.com/support/desk)
* [Documenation](https://e2pdf.com/support/docs)
* [YouTube](https://www.youtube.com/e2pdf)

= PDF DOCUMENT VIEWER: [e2pdf-view] =

* Allows users to view and print PDF documents without leaving your site.
* Preview dynamically created PDF documents prior to downloading, emailing, or purchasing.

= PDF DOCUMENT EDITOR: Built-in =

* Create a PDF from a blank document.
* Upload and edit existing PDF documents.
* Add/Edit text and images.
* Auto-generate PDF documents based on a Wordpress page or post.

= PDF FORMS EDITOR: Built-in =

* Create PDF forms from a blank document.
* Upload and edit existing PDF documents or forms, no need for third-party software.
* Auto-generate PDF forms based on a Wordpress page, post, or web form.
* Use actions and conditions to create dynamic PDF documents.

= PDF DATA INJECTOR: Remotely Generated¹ =

* Map Wordpress pages or post to PDF fields.
* Map web forms to PDF form fields.
* Map signature² fields to PDF form fields.
* Map images² to PDF form fields.

= EMAIL PDF OPTIONS =

* Send as email attachment.
* Send a link in email body to download PDF documents and forms. 

= SAVE DYNAMIC PDF TO SERVER =

* Save form filled PDF documents to static or dynamic folders on your server.

== EXTENSIONS: 3rd Party Integrations ==

* [Wordpress](https://e2pdf.com/extensions/wordpress)
* [Forminator](https://e2pdf.com/extensions/forminator)
* [Formidable Forms](https://e2pdf.com/extensions/formidable)
* [Gravity Forms](https://e2pdf.com/extensions/gravity)
* [Caldera Forms](https://e2pdf.com/extensions/caldera)
* [Divi Contact Forms](https://e2pdf.com/extensions/divi)
* [WooCommerce](https://e2pdf.com/extensions/woocommerce)

== APIs: 3rd Party Integrations ==

* Adobe Sign REST API

= IN DEVELOPMENT³ =

* Contact Form 7
* Ninja Forms

== Terms of Service ==

By continuing to use our plugin you are agreeing to our [Terms of Service](https://e2pdf.com/terms-of-service).

== Additional Information, Definition and Explaination ==

¹ Remotely Generated: Due to the complex nature of the PDF file format, dynamic PDF documents are generating remotely with the E2Pdf API at E2Pdf.com. 
PRIVACY POLICY: We do not collect or store any web form submitted user private data that is sent to the API.

² Selected extension must include the signature field or image field.

³ In Development: Extensions to be added to E2Pdf. [Click here](https://e2pdf.com/support/desk) to request an integration, or the status of an integration.

== HISTORY ==

E2Pdf is the new and highly improved iteration of the [Formidable PRO2PDF plugin](https://wordpress.org/plugins/formidablepro-2-pdf/). Originally designed and coded in 2013 out of a need to print dynamic PDF documents from WordPress forms, PRO2PDF provided the automation necessary for a small insurance broker to produce far more business with the same number of employees.

Today, the E2Pdf plugin and Wordpress extension provide the entire WordPress community with a cost free method of creating dynamic PDF documents – without programming or coding – with one simple shortcode. More information can be found at [E2Pdf.com](https://e2pdf.com)

[youtube https://www.youtube.com/watch?v=BFu78n9-tcM]

== Installation ==

1. Go to your "Plugins" -> "Add New" page in your WordPress admin dashboard
2. Search for "E2Pdf"
3. Click the "Install Now" button
4. Activate the plugin through the "Plugins" menu
5. Create a new Template, activate and use one of the shortcodes available to add PDF to needed page/form and you're done!

== Frequently Asked Questions ==
= Support for Multisite installation =

Yes, plugin supports Network Activation.

= How to add new Fonts? =

To upload new fonts go to E2Pdf -> Settings -> Fonts. After successfull upload font will appear in the "Font Dropdown" in templates.

= Font inside fields for "Uploaded" PDF different =

At this moment, fields are fully recreated and controlled by E2Pdf. To use the original font, you must upload the font to E2Pdf and assign it to the PDF form field(s), or any other created objects from the PDF Builder.

= How to make PDF read-only? =

Set "Inline" checkbox "On" under "Settings" metabox -> Template while Template edit

= How to resize fields/html objects? =

Resize can be completed via "Double" Click on needed field/html object and resized or via "Right Mouse Click" -> "Properties"

== Screenshots ==

1. Export data to PDF from Admin Panel.
2. Templates list Page.
3. Creating new PDF Template.
4. Editing PDF Template.
5. PDF Template Object properties.
6. Settings Page.

== Changelog ==

= 1.15.00 =
*Release Date - 03 May 2021*

* Add: QR Code support
* Add: Barcode support
* Add: Export to "JPG" format support
* Add: "locale" attribute support for [e2pdf-format-date] shortcode
* Add: "Merged Items" support for Formidable Forms
* Add: "Z-index" negative position support
* Add: "Fonts Cache" support
* Add: Fixed height support for HTML table columns
* Add: Rowspan support for HTML table columns
* Add: GravityWiz Nested Forms "Auto PDF" support
* Add: GravityWiz Nested Forms "Visual Mapper" support
* Add: WooCommerce additional product item meta keys
* Add: [default-message] support for Formidable Forms
* Fix: Formidable Forms "Auto Map" duplicated brackets
* Fix: Missing fields with same name on pre-made PDFs usage
* Fix: Do not show "sub-forms" under items list for Formidable Forms
* Fix: Incorrect "color" prevent PDF from generation
* Fix: "Cache" not enabled by default
* Fix: "Multiple Themes" compatibility fix
* Fix: "Beaver Builder" Templates shortcodes fix
* Improvement: "path" attribute return empty value instead empty array if not found
* Improvement: "hr" width 100% by default
* Improvement: pdf.js update (v2.6.347)

= 1.13.40 =
*Release Date - 02 May 2021*

* Add: "[id]" as shortcode attribute for "WooCommerce", "WordPress"
* Add: List of available "Image" sizes
* Fix: Incorrect page detection in some cases
* Fix: Forminator 1.14.11 compatibility fix
* Fix: Minor style fixes

= 1.13.38 =
*Release Date - 14 April 2021*

* Fix: Forminator 1.14.10 "Visual Mapper" "Auto PDF"
* Fix: PHP8 deprecation notices

= 1.13.37 =
*Release Date - 15 March 2021*

* Fix: PHP8 compatibility fix

= 1.13.36 =
*Release Date - 22 February 2021*

* Add: Formidable Forms "Field Keys" support for "Auto Map"
* Add: [e2pdf-download] shortcode support as WooCommerce attribute value
* Fix: Relative "dir" attribute for [e2pdf-save] shortcode incorrect path in some cases
* Fix: "Number" fields not working in some cases
* Fix: Forminator "Auto PDF" radio fields
* Fix: Incorrect "Order ID" for WooCommerce in some cases
* Improvement: Forminator "Auto PDF" fields description support

= 1.13.31 =
*Release Date - 04 February 2021*

* Add: "Visual Mapper" new shortcodes support for WooCommerce

= 1.13.30 =
*Release Date - 02 February 2021*

* Add: Product and Order Items meta data output support for WooCommerce
* Add: Product attributes output for WooCommerce
* Add: Conditions to be used with attributes for WooCommerce email attachments
* Fix: Incorrect "options" render of "lookup" and "dynamic" Formidable Form fields
* Improvement: Better support of "lookup" and "dynamic" Formidable Form fields

= 1.13.28 =
*Release Date - 26 January 2021*

* Add: EU API servers for PDF generation

= 1.13.27 =
*Release Date - 20 January 2021*

* Fix: Compatiability fix with "Dynamic Conditions" for "Elementor"
* Improvement: "Visual Mapper" for Formidable Forms

= 1.13.26 =
*Release Date - 16 January 2021*

* Fix: Forminator do not show all forms list
* Fix: Forminator incorrect form names in some cases

= 1.13.25 =
*Release Date - 07 January 2021*

* Add: Dynamic dataset support for "Divi"
* Improvement: "Add Action"/"Add Condition" actions

= 1.13.23 =
*Release Date - 04 January 2021*

* Add: "table" float CSS support

= 1.13.22 =
*Release Date - 22 December 2020*

* Fix: "e2pdf_model_shortcode_e2pdf_zapier_extension_options" filter
* Fix: WooCommerce incorrect product data in some cases
* Improvement: "Visual Mapper" for WooCommerce

= 1.13.20 =
*Release Date - 14 December 2020*

* Add: Zapier support
* Add: [e2pdf-zapier] shortcode
* Add: A4 (LANDSCAPE) size preset

= 1.13.19 =
*Release Date - 09 December 2020*

* Add: Additional filters to hook "shortcode" attributes
* Fix: Gravity Forms "Conditional Shortcode" fix for [e2pdf-attachment] shortcode
* Fix: Compatibility fix with "All 404 Redirect to Homepage" plugin
* Improvement: [e2pdf-format-date] extended shortcode attributes and values

= 1.13.15 =
*Release Date - 01 December 2020*

* Fix: Incorrectly fired "auto" download in some cases

= 1.13.14 =
*Release Date - 26 November 2020*

* Add: "wpautop" filter to [e2pdf-format-output]
* Fix: "Rulers Grid" not showing in some cases
* Improvement: Do not unselect elements while "Ctrl" pressed

= 1.13.13 =
*Release Date - 24 November 2020*

* Fix: Minor bug fixes

= 1.13.12 =
*Release Date - 21 November 2020*

* Improvement: Max font-size increased to 512

= 1.13.11 =
*Release Date - 18 November 2020*

* Fix: PHP Fatal Error on Gravity Forms in some cases

= 1.13.10 =
*Release Date - 13 November 2020*

* Add: Remove "unsupported" inline html tags automatically
* Add: "data:image" image support
* Improvement: WordPress "Visual Mapper" forced to use standard shortcodes

= 1.13.09 =
*Release Date - 09 November 2020*

* Add: Multiple "Other" checkbox support for Formidable Forms
* Improvement: "Other" radio option better support for Formidable Forms

= 1.13.08 =
*Release Date - 03 November 2020*

* Add: "Tab Order" setting
* Improvement: WordPress shortcodes render
* Fix: PHP warning on "E2Pdf" -> "Export" in some cases
* Fix: "Z-index" option PDF standards
* Fix: Incorrect position of "Radio" buttons in case of "Hide" page action

= 1.13.07 =
*Release Date - 27 October 2020*

* Add: GravityWiz Nested Forms custom E2Pdf templates

= 1.13.06 =
*Release Date - 25 October 2020*

* Fix: Caldera Forms incorrect slugs truncate in some cases
* Fix: Emails failed on WooCommerce in some cases

= 1.13.04 =
*Release Date - 23 October 2020*

* Add: WooCommerce Invoice Status Options
* Add: "html_entity_decode" filter to [e2pdf-format-output]
* Improvement: WooCommerce support

= 1.13.03 =
*Release Date - 14 October 2020*

* Fix: Incorrect font render in some cases
* Fix: "0" position flush elements by default while PDF reupload

= 1.13.02 =
*Release Date - 12 October 2020*

* Fix: Compatibility fix with "Minify HTML" plugin

= 1.13.01 =
*Release Date - 07 October 2020*

* Fix: "Other" value for Gravity Forms Visual Mapper
* Add: Support "Other" value for Gravity Forms "Auto PDF"

= 1.13.00 =
*Release Date - 05 October 2020*

* Fix: jQuery compatibility fix
* Fix: Visual mapper failed for Gravity Forms in some cases
* Fix: Duplicated attachments for Forminator
* Fix: Forminator Visual Mapper
* Fix: Forminator 1.13.5 compatibility fix
* Fix: Rendered value incorrect in some cases
* Fix: Visual Mapper doesn't render styles on template load
* Fix: Caldera Forms incorrect "Image" value render
* Fix: Caldera Forms PHP warning
* Fix: Incorrect images inside "Cart" with 3rd party WooCommerce plugins
* Fix: Empty "attributes" not fired correctly in some cases
* Add: WooCommerce support
* Add: Embedded Formidable Forms for "Auto" PDF
* Add: Global "RTL" option
* Add: Global "Text Align" option
* Add: Forminator built-in additional slugs render
* Add: Forminator eSignature "Auto PDF" support
* Add: Forminator eSignature Visual Mapper support
* Improvement: "flatten" option enabled by default
* Improvement: Visual Mapper for Forminator
* Improvement: HTML/CSS render

= 1.11.08 =
*Release Date - 24 August 2020*

* Fix: [id] shortcode fix for WordPress extension

= 1.11.07 =
*Release Date - 12 August 2020*

* Add: "remove_tags" attribute and filter for [e2pdf-format-output] shortcode
* Add: [post_content] "output" shortcode attribute
* Fix: Incorrect "ireplace" function in some cases
* Fix: Compatibility Fix WordPress 5.5
* Fix: PDFs failed to load in some cases
* Improvement: UI

= 1.11.05 =
*Release Date - 27 July 2020*

* Add: [post_author] "subkey" shortcode attribute
* Add: [e2pdf-user] extended shortcode attributes
* Add: "user_avatar" key support for [e2pdf-user] shortcode
* Add: "substr" filter for [e2pdf-format-output] shortcode
* Add: "View" and "Download" action on E2Pdf -> Export
* Fix: PHP warning on Gravity Forms in some cases
* Fix: Incorrect order of Formidable Forms Repeater fields in some cases

= 1.11.04 =
*Release Date - 07 July 2020*

* Fix: Gravity Forms entries limit fix
* Fix: "headers" PHP notice

= 1.11.03 =
*Release Date - 02 July 2020*

* Add: "responsive" attribute for [e2pdf-view]
* Add: Custom CSS for PDF viewer
* Add: Loading text for PDF viewer
* Add: Additional debug information
* Add: "offset" attribute for [e2pdf-format-date] shortcode
* Fix: Viewer failed to load correctly in some cases
* Fix: Divi Contact Forms undefined variable notice
* Fix: Divi Contact Forms shortcodes do not fire with spam protection on
* Fix: Incorrect output of meta key if value is set to 0

= 1.11.02 =
*Release Date - 09 June 2020*

* Add: Auto restore License Key process
* Add: "create_dir", "create_index", "create_htaccess" attributes for [e2pdf-save] shortcode
* Fix: "e2pdf-view" shortcode for non ajax submissions Caldera Forms
* Fix: "dir" attribute not rendered dynamic values in some cases
* Fix: Minor bug fixes

= 1.11.01 =
*Release Date - 28 May 2020*

* Add: Formidable Forms "Sections" for Auto PDF
* Add: "e2pdf_model_e2pdf_shortcode_attachment_path" filter
* Add: "e2pdf_model_e2pdf_shortcode_save_path" filter
* Add: "e2pdf_controller_frontend_e2pdf_download" action
* Add: "e2pdf_controller_frontend_e2pdf_download_response" action
* Add: "target" attribute for "e2pdf-download"
* Fix: Gravity Forms "Visual Mapper" fails in some cases 
* Fix: Download "file name" incorrect for Microsoft Edge, Safari
* Fix: "inline" attribute ignored in some cases
* Fix: "W3 Total Cache" compatibility fix

= 1.11.00 =
*Release Date - 14 May 2020*

* Add: Text Rotation option
* Add: Vertical align for "HTML" Object
* Add: CSS margin support for p tags
* Add: "site_url" for "e2pdf-view" shortcode
* Add: "e2pdf_extension_render_shortcodes_pre_do_shortcode" filter
* Add: "e2pdf_extension_render_shortcodes_after_do_shortcode" filter
* Add: "e2pdf_model_shortcode_site_url" filter
* Add: "e2pdf_model_shortcode_e2pdf_download_site_url" filter
* Add: "e2pdf_model_shortcode_e2pdf_view_site_url" filter
* Fix: Incorrect element position after element resize in some cases
* Improvement: Visual Mapper for Formidable Forms
* Improvement: Properties settings

= 1.10.11 =
*Release Date - 01 May 2020*

* Add: "e2pdf_controller_templates_max_font_size" filter
* Add: "e2pdf_controller_templates_max_line_height" filter
* Add: "Release Candidate" update option
* Add: "Only Image" for Image/Signature object
* Add: Value "pre-render" filter
* Add: Extended [meta] shortcode for WordPress
* Add: "Caldera Forms" Auto Responder support
* Add: "Preg Match All" filter
* Add: Maintenance Section
* Fix: Divi Contact Forms shortcodes not rendered in some cases
* Fix: "attachment_url" and "attachment_image_url" meta key attributes not fired in some cases
* Fix: Minor style fixes
* Fix: Caldera Forms multipage
* Fix: "Elementor" shortcode widget failed to render
* Fix: Fonts conflict in some cases
* Fix: Divi Contact Forms 4.3.3 Visual Mapper
* Fix: Incorrect "compression" setting in some cases
* Fix: PDF can't be parsed in some cases
* Fix: Firefox mass elements select
* Fix: HTML images not rendered in some cases
* Fix: Shortcode wrappers incorrectly fired on checkbox value
* Fix: Caldera Forms checkbox not rendered in some cases
* Fix: DB columns missed after update in some cases
* Improvement: WordPress Extension
* Improvement: HTML Support
* Improvement: Better image detection
* Improvement: Visual Builder
* Improvement: Image render

= 1.09.10 =
*Release Date - 15 January 2020*

* Add: "Letter Spacing" setting
* Add: "Merge" option for "Actions" and "Conditions"
* Add: Custom "CSS" Html Object support
* Add: Url Generation Link Format option
* Add: .otf fonts support
* Add: "E2Pdf Connected Account" setting
* Add: Templates Bulk Actions: "Activation" and "Deactivation"
* Add: "Global Actions"
* Add: "single_page_mode", "hide", "background", "border" attributes for [e2pdf-view]
* Add: %%_wp_http_referer%%, %%e2pdf_entry_id%% shortcodes support for "Divi"
* Add: Database Debug information
* Add: id="current" for [e2pdf-user] shortcode
* Add: "responsive", "viewer" attributes for [e2pdf-view]
* Add: Support of shortcodes which contains [id] for "Formidable Forms"
* Add: Option to disable WYSIWYG Editor for HTML Object
* Add: Option to disable Local Images Load
* Add: Option to change Images Load Timeout
* Add: "justify" option for HTML Object
* Add: Caldera Forms Conditional Fields support
* Add: "Visual Mapper" show hidden fields option
* Add: Template Revisions
* Fix: Caldera Forms minor bug-fixes
* Fix: Caldera Forms Connected Forms 1.2.2 compatibility
* Fix: Missed font characters in some cases
* Fix: Missed signature images on view action
* Fix: Incorrect fields render for "Actions" and "Conditions"
* Fix: "New Lines to BR" filter not fired on view/preview action
* Fix: "UC Browser" compatibility
* Fix: "Debug" page doesn't appear on "Turn on Debug mode" setting
* Fix: [frm-math] shortcode for "Formidable Forms" usage inside Template directly
* Fix: WordPress Page Builder – Beaver Builder Compatibility
* Fix: RTL Support
* Fix: Hidden pages missed on "Preview" and "View" Template action
* Fix: "Divi Contact Forms" auto download
* Fix: WordPress 5.3 Styles
* Fix: Missed fields for "Gravity Forms" inside "Visual Mapper"
* Fix: "Hide" action for pages fired incorrectly in some cases
* Fix: Incorrect render of values in some cases
* Fix: "Visual Mapper" fails for "Caldera Forms" in some cases
* Fix: UI minor bug fixes
* Fix: Compatibility with Divi 3.27
* Fix: Incorrect render of values in some cases
* Fix: Fields data were not saving in some cases
* Improvement: Previous versions compatibility
* Improvement: Extended "Debug" information
* Improvement: pdf.js update (v2.3.200)
* Improvement: Templates load
* Improvement: Translation
* Improvement: Errors and Message Notifications
* Improvement: Optimization

= 1.08.09 =
*Release Date - 07 August 2019*

* Add: "Nl2br" option for "e2pdf-html"
* Add: Unlink paid License Key option
* Add: "attachment_image_url" attribute for [e2pdf-meta] shortcode support
* Add: "Events Manager" render shortcodes support
* Add: "Divi Builder" support
* Add: Extended 3rd party plugins support for WordPress extension
* Add: "Visual Mapper" meta keys support for WordPress extension
* Add: "nl2br" filter for [e2pdf-format-output] shortcode
* Add: Permission settings
* Add: Dynamic shortcode support for "WordPress" extension inside Widgets
* Add: "Hide (If Empty)" and "Hide Page (if Empty)" properties for HTML object
* Add: "Preg Replace" option for fields and objects
* Add: "Replace Value" and "Auto-Close" options for "Visual Mapper"
* Fix: "Visual Mapper" styles for Forminator
* Fix: Conflict with Elementor
* Fix: Conflict with SiteOrigin
* Fix: "Caldera Forms" incorrect support for checkbox with "Show Values" option
* Fix: "preg_replace" error
* Improvement: "Auto PDF"
* Improvement: UI
* Improvement: Optimization

= 1.07.11 =
*Release Date - 24 June 2019*

* Add: Serialized post meta fields support
* Add: "attachment_url", "path" attributes for WordPress [meta key="x"] shortcode
* Add: Post terms support
* Add: [terms key="x"] shortcode for WordPress posts/pages support
* Add: "pdf" attribute for [e2pdf-download] shortcode
* Add: "Popup Maker" support
* Add: "overwrite" attribute for [e2pdf-save] shortcode
* Add: "Entries" cache support
* Add: Cache support
* Add: "Auto Form" Gravity Forms support
* Add: "Close" button while creating new template
* Add: Gravity Forms support
* Add: "attachment" attribute for [e2pdf-save] shortcode
* Add: [e2pdf-arg] shortcode suppport
* Add: [post_thumbnail] shortcode for WordPress extension
* Fix: "Gravity Forms" does not render values inside mail notification in some cases
* Fix: Missing "Actions" and "Conditions" for pages while re-upload PDF
* Fix: "Visual Mapper" fails for "Caldera Forms" in some cases
* Fix: "Visual Mapper" not rendered correctly for "Gravity Forms" in some cases
* Fix: "Auto Form" Caldera Forms dropdown
* Fix: PHP warnings on signature field in some cases
* Fix: "Auto PDF" radio group names
* Fix: Some shortcodes not fired correctly
* Fix: Backward compatibility with WordPress 4.0
* Fix: "Auto PDF" option visible on extension change
* Fix: New pages do not respect global E2Pdf Template size option
* Fix: Incorrect file name while download in some cases
* Improvement: Better support for 3rd party WordPress plugins
* Improvement: Optimization
* Improvement: UI
* Improvement: Translation
* Improvement: Filters

= 1.06.02 =
*Release Date - 10 April 2019*

* Add: Custom post types support
* Add: [e2pdf-user] shortcode support
* Add: [e2pdf-wp] shortcode support
* Add: [e2pdf-content] shortcode support
* Add: Custom field names
* Add: "Auto Form from PDF" additional options
* Add: "Meta" Title, Subject, Author and Keywords PDF options
* Add: "e2pdf_extension_render_shortcodes_tags" filter
* Add: [e2pdf-view] shortcode additional attributes: page, zoom, nameddest, pagemode
* Fix: "Error" show if failed while creating "Template"
* Fix: WordPress Pages/Posts not showing all items
* Fix: Notice on "e2pdf-image" and "e2pdf-signature" render
* Fix: [e2pdf-exclude] not process shortcodes inside
* Fix: [e2pdf-download] incorrect button title in some cases
* Fix: "Attachments" missing in some cases due incorrect "PDF Name"
* Fix: "Auto Form from PDF" pre-built template radio/checkbox empty
* Fix: "Import" item replace shortcodes inside "Email" body and "Success Messages"
* Improvement: WordPress extension
* Improvement: pdf.js update (v2.0.943)
* Improvement: "Deactivate" template while moving to "Trash"
* Improvement: Translation

= 1.05.03 =
*Release Date - 23 February 2019*

* Add: "Auto Form" from pre-built E2Pdf Template
* Add: "Formidable Forms" Item import options
* Add: "Pagination" and "Screen" options for Templates list
* Fix: "Forminator" incorrect field IDs while "Auto Form"
* Fix: "Replace PDF" failed in some cases (Chrome 72.0.3626.109)
* Fix: "Replace PDF" css
* Fix: Caldera Forms "Auto Form" empty field values
* Fix: Backup failed in some cases
* Fix: "E2Pdf" css style affected other pages
* Improvement: Templates activation/deactivation action
* Improvement: Optimization
* Improvement: Translation

= 1.04.07 =
*Release Date - 11 February 2019*

* Add: Possibility to disable extensions
* Add: "Forminator" "Disable store submissions in my database" support
* Add: "Caldera Forms" Connected Forms support
* Add: "Download" and "View" links generation based on saved PDFs
* Add: Auto Form from PDF for "Formidable Forms", "Caldera Forms", "Forminator"
* Add: "highlight" property for e2pdf-link
* Add: "search", "replace", "ireplace" attributes for [e2pdf-format-output] shortcode
* Add: Changing "Page ID" for elements with "Actions" and "Conditions"
* Fix: "PHP" Warning on empty "LIKE" "NOT_LIKE" condition value
* Fix: "Forminator" textarea field type "Auto PDF"
* Fix: "Visual Mapper" for "Forminator PRO" 1.6.1
* Fix: "Formidable Forms" Signature field (2.0.1) compatibility
* Fix: Image render failed in some cases
* Fix: "Visual Mapper" not rendered correctly for "Forminator" in some cases
* Fix: "Incorrect" element position with "Auto PDF" and "Free" License Type in some cases
* Fix: "Filename" for [e2pdf-view] shortcode
* Fix: "Pages" and "Elements" possible overload issue
* Fix: "e2pdf-signature" failed on load in some cases
* Improvement: Translation
* Improvement: Templates list load time

= 1.03.07 =
*Release Date - 24 December 2018*

* Add: Additional checks for "Visual Mapper"
* Add: Formidable Forms "Repeatable" fields support for e2pdf-" shortcodes
* Add: Display element "Type" inside properties window
* Fix: "Formidable Forms" Visual Mapper error with address field in some cases
* Fix: Z-index issue in some cases
* Fix: "Mozilla Firefox" PDF re-upload new tab
* Fix: Incorrect page size after E2Pdf Template load in some cases
* Fix: "Divi" extension compatibility fix with 3.18.7
* Fix: "e2pdf-format-output" shortcode warning fix
* Fix: "e2pdf-" shortcodes incorrect render for image and signature field types
* Fix: PHP warnings on settings page
* Fix: "auto" and "inline" options failed on "false" state
* Fix: "frontend.js" missed for "admin" users
* Fix: Default value for border color
* Fix: "Border" on fields after editing PDF
* Fix: Incorrect "HTML" element text position
* Fix: Incorrect "HTML" size
* Fix: "Divi" delete item error in some cases
* Fix: "Actions" and "Conditions" replace shortcodes among import action
* Fix: "Upload PDF" item and extension not updated in some cases
* Fix: "Rectangle" minimum width
* Fix: "Visual Mapper" encoding issue in some cases
* Fix: "Visual Mapper" for "Formidable Forms" showed draft entry in some cases
* Fix: "Visual Mapper" memory leak
* Fix: "Visual Mapper" failed in some cases
* Improvement: "Visual Mapper" checks
* Improvement: "Image" load optimization
* Improvement: Text positions inside inputs
* Improvement: Auto PDF
* Improvement: UI
* Improvement: Translation

= 1.02.02 =
*Release Date - 02 December 2018*

* Add: "Adobe Sign" REST API support
* Fix: "Actions" not fired in some cases
* Fix: "Divi" duplicate replacement of value in some cases
* Fix: "Forminator" empty forms list while creating Template
* Fix: Notifications not showed in some cases
* Fix: Shortcode attributes not rendered correctly in some cases
* Improvement: Optimization

= 1.01.01 =
*Release Date - 26 October 2018*

* Add: "Forminator" support
* Add: Extensions unlock
* Fix: Minor bug fixes

= 1.00.13 =
*Release Date - 15 October 2018*

* Add: "Line Height" option for "textarea" field type
* Add: "Signature" field
* Add: "E-signature" field type
* Add: Typed "Signature" support for all extensions
* Add: "length" property for "input", "textarea" fields
* Add: "comb" (Combination of Characters) property for "input", "textarea" fields
* Add: Notification on failed PDF re-upload
* Add: Notification on failed PDF upload
* Add: "class" attribute for "e2pdf-download" and "e2pdf-view" shortcodes
* Add: Privacy Policy
* Fix: "Divi" item not found in some cases
* Fix: Typed "Signature" color fix
* Fix: Minor style fixes
* Fix: Checkbox value contains comma
* Fix: Signature text generation Formidable Forms
* Fix: Multiple repeat sections Formidable Forms
* Fix: Mozilla Firefox compatibility
* Improvement: "Visual Mapper"
* Improvement: Signature quality, options
* Improvement: Update Process

= 1.00.00 =
*Release Date - 20 August 2018*

* Initial Release

== Upgrade Notice ==

= 1.00.00 =

Initial Release
