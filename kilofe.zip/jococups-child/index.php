<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-AU"
	prefix="og: https://ogp.me/ns#" >
<head profile="http://gmpg.org/xfn/11">



<script>
(function(g,e,o,t,a,r,ge,tl,y,s){
g.getElementsByTagName(o)[0].insertAdjacentHTML('afterbegin','<style id="georedirect1535761335707style">body{opacity:0.0 !important;}</style>');
s=function(){g.getElementById('georedirect1535761335707style').innerHTML='body{opacity:1.0 !important;}';};
t=g.getElementsByTagName(o)[0];y=g.createElement(e);y.async=true;
y.src='https://g792337340.co/gr?id=-LLHVZFDpq7sOEBfxdg_&refurl='+g.referrer+'&winurl='+encodeURIComponent(window.location);
t.parentNode.insertBefore(y,t);y.onerror=function(){s()};
georedirect1535761335707loaded=function(redirect){var to=0;if(redirect){to=5000};
setTimeout(function(){s();},to)};
})(document,'script','head');
</script>

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="google-site-verification" content="5G9qn1_lm8PgiyPB974pqUKhjU6DxICiTw0IdZdIt2M" />


	<title>JOCO Cups | Glass Reusable Coffee Cups</title>

	

	<link rel="icon" href="https://jococups.com/wp-content/themes/jococups/img/favicon.ico"/>

	
<!-- All in One SEO Pack 3.2.10 by Michael Torbert of Semper Fi Web Design[1184,1237] -->
<script type="application/ld+json" class="aioseop-schema">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://jococups.com/#organization","url":"https://jococups.com/","name":"JOCO Cups","sameAs":["https://www.instagram.com/jococups/","https://www.facebook.com/jococups"],"contactPoint":{"@type":"ContactPoint","telephone":"+610342412036","contactType":"customer support"}},{"@type":"WebSite","@id":"https://jococups.com/#website","url":"https://jococups.com/","name":"JOCO Cups","publisher":{"@id":"https://jococups.com/#organization"},"potentialAction":{"@type":"SearchAction","target":"https://jococups.com/?s={search_term_string}","query-input":"required name=search_term_string"}},{"@type":"WebPage","@id":"https://jococups.com/#webpage","url":"https://jococups.com/","inLanguage":"en-AU","name":"Home","isPartOf":{"@id":"https://jococups.com/#website"},"datePublished":"2019-06-04T15:48:43+10:00","dateModified":"2021-02-05T01:46:47+11:00","about":{"@id":"https://jococups.com/#organization"}}]}</script>
<link rel="canonical" href="https://jococups.com/" />
<meta property="og:type" content="website" />
<meta property="og:title" content="JOCO Cups" />
<meta property="og:description" content="Glass Reusable Coffee Cups" />
<meta property="og:url" content="https://jococups.com/" />
<meta property="og:site_name" content="JOCO Cups" />
<meta property="og:image" content="https://jococups.com/wp-content/plugins/all-in-one-seo-pack/images/default-user-image.png" />
<meta property="og:image:secure_url" content="https://jococups.com/wp-content/plugins/all-in-one-seo-pack/images/default-user-image.png" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="JOCO Cups" />
<meta name="twitter:description" content="Glass Reusable Coffee Cups" />
<meta name="twitter:image" content="https://jococups.com/wp-content/plugins/all-in-one-seo-pack/images/default-user-image.png" />
<!-- All in One SEO Pack -->
<link rel='dns-prefetch' href='//js.jilt.com' />
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/jococups.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.3.8"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='sb_instagram_styles-css'  href='https://jococups.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=2.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://jococups.com/wp-includes/css/dist/block-library/style.min.css?ver=5.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://jococups.com/wp-content/plugins/woo-gutenberg-products-block/build/style.css?ver=2.4.4' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='flowplayer-css-css'  href='https://jococups.com/wp-content/plugins/easy-video-player/lib/skin/skin.css?ver=5.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='menu-image-css'  href='https://jococups.com/wp-content/plugins/menu-image/includes/css/menu-image.css?ver=2.9.5' type='text/css' media='all' />
<link rel='stylesheet' id='wpsl-styles-css'  href='https://jococups.com/wp-content/plugins/wp-store-locator/css/styles.min.css?ver=2.2.232' type='text/css' media='all' />
<link rel='stylesheet' id='afterpay_css-css'  href='https://jococups.com/wp-content/plugins/afterpay-gateway-for-woocommerce/css/afterpay.css?ver=5.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='swatches-and-photos-css'  href='https://jococups.com/wp-content/plugins/woocommerce-variation-swatches-and-photos/assets/css/swatches-and-photos.css?ver=5.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='glider-css-css'  href='https://jococups.com/wp-content/themes/jococups/css/glider.css?ver=5.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='parent-style-css'  href='https://jococups.com/wp-content/themes/jococups/style.css?ver=5.3.8' type='text/css' media='all' />
<script type='text/javascript' src='https://jococups.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
<script type='text/javascript' src='https://jococups.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://jococups.com/wp-content/plugins/easy-video-player/lib/flowplayer.min.js?ver=5.3.8'></script>
<script type='text/javascript' src='https://jococups.com/wp-content/plugins/afterpay-gateway-for-woocommerce/js/afterpay.js?ver=5.3.8'></script>
<script type='text/javascript' src='https://jococups.com/wp-content/themes/jococups/js/flickity.pkgd.min.js?ver=1'></script>
<script type='text/javascript' src='https://jococups.com/wp-content/themes/jococups/js/scripts.js?v=5&#038;ver=1'></script>
<script type='text/javascript' src='https://jococups.com/wp-content/themes/jococups/js/glider.js?ver=1'></script>
<link rel='https://api.w.org/' href='https://jococups.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://jococups.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://jococups.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.3.8" />
<meta name="generator" content="WooCommerce 3.8.1" />
<link rel='shortlink' href='https://jococups.com/' />
<link rel="alternate" type="application/json+oembed" href="https://jococups.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjococups.com%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://jococups.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fjococups.com%2F&#038;format=xml" />
<!-- This content is generated with the Easy Video Player plugin v1.1.8 - http://noorsplugin.com/wordpress-video-plugin/ --><script>flowplayer.conf.embed = false;flowplayer.conf.keyboard = false;</script><!-- Easy Video Player plugin --><meta name="referrer" content="always"/>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	
<!-- WooCommerce Facebook Integration Begin -->

<script type='text/javascript'>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
</script>

<script>
fbq('init', '1028530147350810', {}, {
    "agent": "woocommerce-3.8.1-1.9.11"
});

fbq('track', 'PageView', {
    "source": "woocommerce",
    "version": "3.8.1",
    "pluginVersion": "1.9.11"
});

document.addEventListener('DOMContentLoaded', function() {
  jQuery && jQuery(function($){
    $('body').on('added_to_cart', function(event) {
      // Ajax action.
      $.get('?wc-ajax=fb_inject_add_to_cart_event', function(data) {
        $('head').append(data);
      });
    });
  });
}, false);

</script>
<!-- DO NOT MODIFY -->
<!-- WooCommerce Facebook Integration end -->
    <link rel="icon" href="https://jococups.com/wp-content/uploads/sites/7/2020/12/cropped-JocoCups-32x32.png" sizes="32x32" />
<link rel="icon" href="https://jococups.com/wp-content/uploads/sites/7/2020/12/cropped-JocoCups-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://jococups.com/wp-content/uploads/sites/7/2020/12/cropped-JocoCups-180x180.png" />
<meta name="msapplication-TileImage" content="https://jococups.com/wp-content/uploads/sites/7/2020/12/cropped-JocoCups-270x270.png" />
	
		


	
		<!-- Google Tag Manager -->
		<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-TQBLL2T');</script>
	<!-- End Google Tag Manager -->
	
<script>
jQuery(document).ready(function(){
	
	jQuery(function() {      
    var isMobile = window.matchMedia("only screen and (max-width: 767px)").matches;

    if (isMobile) {
		
		   //Mobile images for velvet grip straw 10'
		   jQuery(".postid-26752 ul.slides li:nth-child(5) img").attr("src","https://jococups.com/wp-content/uploads/sites/7/2020/12/JOCO.COM-Product-Dimensions-Module-VGS_10_Mobile.png");			
		   jQuery(".postid-26752 ul.slides li:nth-child(5) img").attr("srcset","https://jococups.com/wp-content/uploads/sites/7/2020/12/JOCO.COM-Product-Dimensions-Module-VGS_10_Mobile.png");
		   
		   
		   //Mobile images for velvet grip straw 8.5'
		   jQuery(".postid-26747 ul.slides li:nth-child(5) img").attr("src","https://jococups.com/wp-content/uploads/sites/7/2020/12/JOCO.COM-Product-Dimensions-Module-VGS_8_Mobile.png");			
		   jQuery(".postid-26747 ul.slides li:nth-child(5) img").attr("srcset","https://jococups.com/wp-content/uploads/sites/7/2020/12/JOCO.COM-Product-Dimensions-Module-VGS_8_Mobile.png");
		   
		   //Mobile images for velvet grip straw 7'
		   jQuery(".postid-26729 ul.slides li:nth-child(5) img").attr("src","https://jococups.com/wp-content/uploads/sites/7/2020/12/JOCO.COM-Product-Dimensions-Module-VGS_7_Mobile.png");			
		   jQuery(".postid-26729 ul.slides li:nth-child(5) img").attr("srcset","https://jococups.com/wp-content/uploads/sites/7/2020/12/JOCO.COM-Product-Dimensions-Module-VGS_7_Mobile.png");
		   
		   //Mobile image for Active Flask 17Oz 
		   jQuery(".postid-260179 ul.slides li:nth-child(2) img,.postid-260179 ul.slides li:nth-child(2) img,.postid-260179 ul.slides li:nth-child(2) img").attr("src","https://jococups.com/wp-content/uploads/sites/7/2021/03/JOCO.COM-Product-Dimensions-Module-ActiveFlask_Mobile.jpg");
		   jQuery(".postid-260179 ul.slides li:nth-child(2) img,.postid-260179 ul.slides li:nth-child(2) img,.postid-260179 ul.slides li:nth-child(2) img").attr("srcset","https://jococups.com/wp-content/uploads/sites/7/2021/03/JOCO.COM-Product-Dimensions-Module-ActiveFlask_Mobile.jpg");
		}         
	 });
	
	//Update Utility lid GIF runtime - global and usa	
	jQuery(".postid-154355 ul.slides li:nth-child(3) img,.postid-154476 ul.slides li:nth-child(3) img,.postid-154493 ul.slides li:nth-child(3) img").attr("src","https://jococups.com/wp-content/themes/jococups/utility-cup-opti.gif");
	jQuery(".postid-154355 ul.slides li:nth-child(3) img,.postid-154476 ul.slides li:nth-child(3) img,.postid-154493 ul.slides li:nth-child(3) img").attr("srcset","https://jococups.com/wp-content/themes/jococups/utility-cup-opti.gif");
	 
	//Update Utility lid GIF runtime - NZ
	jQuery(".postid-109006 ul.slides li:nth-child(3) img,.postid-109007 ul.slides li:nth-child(3) img,.postid-109008 ul.slides li:nth-child(3) img").attr("src","https://jococups.com/wp-content/themes/jococups/utility-cup-opti.gif");
	jQuery(".postid-109006 ul.slides li:nth-child(3) img,.postid-109007 ul.slides li:nth-child(3) img,.postid-109008 ul.slides li:nth-child(3) img").attr("srcset","https://jococups.com/wp-content/themes/jococups/utility-cup-opti.gif");
	
	//Update actvie flask 17oz - global and usa	
	 
	jQuery(".postid-260179 ul.slides li:first-child img,.postid-260179 ul.slides li:first-child img,.postid-260179 ul.slides li:first-child img").attr("src","https://jococups.com/wp-content/themes/jococups/ActiveFlaskMovie.gif");
	jQuery(".postid-260179 ul.slides li:first-child img,.postid-260179 ul.slides li:first-child img,.postid-260179 ul.slides li:first-child img").attr("srcset","https://jococups.com/wp-content/themes/jococups/ActiveFlaskMovie.gif");
	
	// Co brand page refresh gif on click	
	jQuery("b.refresh-retail-gif").click(function(){
		jQuery(".points-flexslider ul.slides li:first-child img").attr("src","https://jococups.com/wp-content/uploads/sites/7/2020/09/Retail-Impact-2020.gif");
	});
	jQuery("b.refresh-corporate-gif").click(function(){
		jQuery(".points-flexslider ul.slides li:nth-child(2) img").attr("src","https://jococups.com/wp-content/uploads/sites/7/2020/09/Retail-Impact-2020.gif");
	});
	
	if(jQuery( "body" ).hasClass( "page-id-23" ))
	{
		// checkout page code
		 jQuery(window).scroll(function() {
			if (jQuery(this).scrollTop() >= 400 ) 
			{
				jQuery(".custom-notice").addClass("fixed");
			}
			else
			{
				jQuery(".custom-notice").removeClass("fixed");
			}
		 });
		 
			if (jQuery("#select2-billing_country-container").text()==="United Kingdom (UK)") {
				// uk selected
				jQuery(".custom-notice span.global-notice").css("display","none");
				jQuery(".custom-notice span.uk-notice").show(500); //.css("display","block");
			} 
			else
			{
				jQuery(".custom-notice span.global-notice").show(500);//.css("display","block");
				jQuery(".custom-notice span.uk-notice").css("display","none");
			}
	}
	jQuery( document ).ajaxComplete(function() {
		jQuery( ":input.country_to_state" ).on("change",function() {
			if (jQuery("#select2-billing_country-container").text()==="United Kingdom (UK)") {
				// uk selected
				jQuery(".custom-notice span.global-notice").css("display","none");
				jQuery(".custom-notice span.uk-notice").show(500); //.css("display","block");
			} 
			else
			{
				jQuery(".custom-notice span.global-notice").show(500);//.css("display","block");
				jQuery(".custom-notice span.uk-notice").css("display","none");
			}
		});
	});
	
	jQuery("label.woocommerce-form__label.woocommerce-form__label-for-checkbox.inline span").addClass("jococups-checked");        
	jQuery("input#wpsl-search-input").attr("placeholder","Enter Location");
	
	 jQuery('input#ship-to-different-address-checkbox,input#mailchimp_woocommerce_newsletter').change(function() {
        if(this.checked) 
		{
			jQuery(this).parent().parent().find("label.woocommerce-form__label-for-checkbox span").removeClass("jococups-unchecked");
            jQuery(this).parent().parent().find("label.woocommerce-form__label-for-checkbox span").addClass("jococups-checked");        
		}
		else
		{
			jQuery(this).parent().parent().find("label.woocommerce-form__label-for-checkbox span").removeClass("jococups-checked");        
			jQuery(this).parent().parent().find("label.woocommerce-form__label-for-checkbox span").addClass("jococups-unchecked");
		}
       
    });
	
	// Code to change Add to cart/Not available button text runtime
	jQuery(document).on("click",".single-product .select-option.swatch-wrapper",function(){
		if(jQuery(".woocommerce-variation-add-to-cart").hasClass("woocommerce-variation-add-to-cart-enabled"))
		{
			// Product in stock
			jQuery(".btn-cart-text").html("Add to cart");
		}
		else
		{
			// Product out of stock
			jQuery(".btn-cart-text").html("Sold out");
		}
		
	});
	
	//jQuery('.mz-expand span a').html(""); 
	
});
</script>
<style>

a.cm-zoom.mz-thumb,.lightbox-added.mz-thumb ,.mz-thumb {
    clear: both!important;
    display: block!important;
    margin: auto!important;
    width: 100%!important;
} 

.MagicToolboxContainer {
    position: relative!important;
}
.MagicToolboxSelectorsContainer {
    position: absolute!important;
    bottom: 0px!important;
	z-index: 999999999;
	    overflow: hidden!important;

}

figure.mz-figure.mz-hover-zoom.mz-ready span,.mz-expand span {
    opacity: 0!important;
}

@media only screen and (min-width:901px)
{
.MagicToolboxContainer {
    position: relative!important;
	    overflow: hidden!important;
		top: 70px;
}
.MagicToolboxSelectorsContainer div {
    bottom: -5px!important;
    position: absolute;
    left: 20px;
	overflow: hidden!important;

}
.MagicToolboxSelectorsContainer div a img {
    margin-bottom: 15px;
}

a#MagicZoomPlusImage_Main_Product24185,a#MagicZoomPlusImage_Main_Product24188,a#MagicZoomPlusImage_Main_Product101651 {
    margin-left: 60px!important;
    top: 40px;
}
.MagicToolboxSelectorsContainer {
    padding-top: 75px;
}
body.single.single-product div div div#product-23894  div div div div div a#MagicZoomPlusImage_Main_Product23894:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-154493 div div div div div a#MagicZoomPlusImage_Main_Product154493:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-154476 div div div div div a#MagicZoomPlusImage_Main_Product154476:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-154355 div div div div div a#MagicZoomPlusImage_Main_Product154355:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-101651 div div div div div a#MagicZoomPlusImage_Main_Product101651:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26944  div div div div div a#MagicZoomPlusImage_Main_Product26944:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26925  div div div div div a#MagicZoomPlusImage_Main_Product26925:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26752  div div div div div a#MagicZoomPlusImage_Main_Product26752:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26747  div div div div div a#MagicZoomPlusImage_Main_Product26747:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26729  div div div div div a#MagicZoomPlusImage_Main_Product26729:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26699  div div div div div a#MagicZoomPlusImage_Main_Product26699:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26665  div div div div div a#MagicZoomPlusImage_Main_Product26665:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25091  div div div div div a#MagicZoomPlusImage_Main_Product25091:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25056  div div div div div a#MagicZoomPlusImage_Main_Product25056:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25053  div div div div div a#MagicZoomPlusImage_Main_Product25053:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25050  div div div div div a#MagicZoomPlusImage_Main_Product25050:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25046  div div div div div a#MagicZoomPlusImage_Main_Product25046:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25041  div div div div div a#MagicZoomPlusImage_Main_Product25041:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24463  div div div div div a#MagicZoomPlusImage_Main_Product24463:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24455  div div div div div a#MagicZoomPlusImage_Main_Product24455:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24403  div div div div div a#MagicZoomPlusImage_Main_Product24403:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24246  div div div div div a#MagicZoomPlusImage_Main_Product24246:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24245  div div div div div a#MagicZoomPlusImage_Main_Product24245:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24188  div div div div div a#MagicZoomPlusImage_Main_Product24188:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24185  div div div div div a#MagicZoomPlusImage_Main_Product24185:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-23894  div div div div div a#MagicZoomPlusImage_Main_Product23894:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-15859  div div div div div a#MagicZoomPlusImage_Main_Product15859:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-15883  div div div div div a#MagicZoomPlusImage_Main_Product15883:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-15312  div div div div div a#MagicZoomPlusImage_Main_Product15312:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-14821  div div div div div a#MagicZoomPlusImage_Main_Product14821:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-2909   div div div div div a#MagicZoomPlusImage_Main_Product2909:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-11448  div div div div div a#MagicZoomPlusImage_Main_Product11448:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-6829   div div div div div a#MagicZoomPlusImage_Main_Product6829:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-4206   div div div div div a#MagicZoomPlusImage_Main_Product4206:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-3967   div div div div div a#MagicZoomPlusImage_Main_Product3967:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-3631   div div div div div a#MagicZoomPlusImage_Main_Product3631:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-2143   div div div div div a#MagicZoomPlusImage_Main_Product2143:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img,
body.single.single-product div div div#product-260179   div div div div div a#MagicZoomPlusImage_Main_Product260179:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img {
width: auto!important;
}

/* USA products */
body.single.single-product div div div#product-154493 div div div div div a#MagicZoomPlusImage_Main_Product154493:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-154476 div div div div div a#MagicZoomPlusImage_Main_Product154476:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-154355 div div div div div a#MagicZoomPlusImage_Main_Product154355:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-103403 div div div div div a#MagicZoomPlusImage_Main_Product103403:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-103411 div div div div div a#MagicZoomPlusImage_Main_Product103411:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-101651 div div div div div a#MagicZoomPlusImage_Main_Product101651:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26752  div div div div div a#MagicZoomPlusImage_Main_Product26752 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26747  div div div div div a#MagicZoomPlusImage_Main_Product26747 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-26729  div div div div div a#MagicZoomPlusImage_Main_Product26729 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25091  div div div div div a#MagicZoomPlusImage_Main_Product25091 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25056  div div div div div a#MagicZoomPlusImage_Main_Product25056 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25053  div div div div div a#MagicZoomPlusImage_Main_Product25053 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25050  div div div div div a#MagicZoomPlusImage_Main_Product25050 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25046  div div div div div a#MagicZoomPlusImage_Main_Product25046 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-25041  div div div div div a#MagicZoomPlusImage_Main_Product25041 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24463  div div div div div a#MagicZoomPlusImage_Main_Product24463 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24455  div div div div div a#MagicZoomPlusImage_Main_Product24455 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24403  div div div div div a#MagicZoomPlusImage_Main_Product24403 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24246  div div div div div a#MagicZoomPlusImage_Main_Product24246 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24245  div div div div div a#MagicZoomPlusImage_Main_Product24245 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24188  div div div div div a#MagicZoomPlusImage_Main_Product24188 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-24185  div div div div div a#MagicZoomPlusImage_Main_Product24185 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-23894  div div div div div a#MagicZoomPlusImage_Main_Product23894 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-15859  div div div div div a#MagicZoomPlusImage_Main_Product15859 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-15883  div div div div div a#MagicZoomPlusImage_Main_Product15883 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-15312  div div div div div a#MagicZoomPlusImage_Main_Product15312 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-14821  div div div div div a#MagicZoomPlusImage_Main_Product14821 :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-2909   div div div div div a#MagicZoomPlusImage_Main_Product2909  :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-102359 div div div div div a#MagicZoomPlusImage_Main_Product102359:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-102358 div div div div div a#MagicZoomPlusImage_Main_Product102358:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-4206   div div div div div a#MagicZoomPlusImage_Main_Product4206  :not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-102357 div div div div div a#MagicZoomPlusImage_Main_Product102357:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-102356 div div div div div a#MagicZoomPlusImage_Main_Product102356:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-162796 div div div div div a#MagicZoomPlusImage_Main_Product162796:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-162797 div div div div div a#MagicZoomPlusImage_Main_Product162797:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img 
{
width: auto!important;
}
      

/* NZ products */
body.single.single-product div div div#product-109006 div div div div div a#MagicZoomPlusImage_Main_Product109006:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-109007 div div div div div a#MagicZoomPlusImage_Main_Product109007:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img ,
body.single.single-product div div div#product-109008 div div div div div a#MagicZoomPlusImage_Main_Product109008:not(.mz-no-rt-width-css) > .mz-figure:not(.mz-no-rt-width-css) > img 	  
{ 
width: auto!important;
}
    																											
}
figure.mz-figure.mz-hover-zoom.mz-ready {
    background: transparent!important;
	
}
.mz-lens ,.mz-zoom-window,.mz-expand-thumbnails.mz-fade.mz-visible,.mz-expand .mz-expand-stage .mz-image-stage,.mz-expand{
    background: #FFF7EE!important;
	
}
button.mz-button.mz-button-close:before,button.mz-button.mz-button-prev:before, button.mz-button.mz-button-next:before
{
	color:#373737;
}
.woocommerce div.product div.images .woocommerce-product-gallery__image--placeholder {
    border: none!important;
}
@media only screen and (max-width:900px)
{
a.cm-zoom.mz-thumb, .lightbox-added.mz-thumb, .mz-thumb {
    width: auto!important;
    display: inline-block;
    margin: auto!important;
    clear: none!important;
}
.MagicToolboxSelectorsContainer {
    position: initial!important;
}
.MagicToolboxContainer {
    position: initial!important;
}
.single-product > .woocommerce {
    padding-top: 70px;
}
figure.mz-figure.mz-hover-zoom.mz-ready {
	padding-top:5px!important;
}
div.MagicToolboxContainer.selectorsLeft .MagicToolboxSelectorsContainer, div.MagicToolboxContainer.selectorsRight .MagicToolboxSelectorsContainer {
    margin-bottom: -24px!important;
    margin-top: 22px!important; 
}
.MagicToolboxSelectorsContainer {   
    z-index: 9!important;
}
}

button#place_order[disabled=disabled] {
    background: #373737!important;
    color: #fff8ef;
}
div#refresh_captcha a {
    color: #373737;
    font-family: 'museo-sans';
    text-decoration: none;
}
</style>
</head>

<body class="home page-template page-template-template-home page-template-template-home-php page page-id-2  site-wide-open theme-jococups woocommerce-no-js">
	
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TQBLL2T"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
	
				<div id="site-wide">
				<div class="container">
				<p>Free express shipping on AU domestic orders over $80 | Shop now with Afterpay</p>						
					<span class="close-box">
						<span></span>
						<span></span>
					</span>	
				</div>
			</div>
			
	<div id="search-form">
		<a href="/" class="logo">
			<img src="https://jococups.com/wp-content/uploads/sites/7/2020/12/JocoCups.png" width="150" height="150" alt=""/>
		</a>
		<form form method="get" action="https://jococups.com/" id="searchform" class="searchform">
			<input type="text" value="" name="s" id="s" placeholder="Search" />
			<input type="submit" id="searchsubmit" value="Search" />
			<input type="hidden" name="post_type" value="product" />
		</form>
		<span class="close-box">
			<span></span>
			<span></span>
		</span>
	</div>	
	
	<div id="site-header">
		<a href="/" class="logo">
			<img src="https://jococups.com/wp-content/uploads/sites/7/2020/12/JocoCups.png" width="150" height="150" alt=""/>
			<img src="https://jococups.com/wp-content/uploads/sites/7/2020/12/JOCO_Logo_HD_sandstone.png" width="150" height="150" alt="" class="logo_light" />
		</a>
		<span id="menu-button">
			<span></span>
			<span></span>
			<span></span>
		</span>
		<div id="menu">
			<ul id="main-menu" class="navbar-nav"><li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-24118" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown menu-item-24118 nav-item"><a href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle nav-link" id="menu-item-dropdown-24118">Shop<span></span></a>
<ul class="dropdown-menu" aria-labelledby="menu-item-dropdown-24118" role="menu">

<!--
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-163056" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-163056 nav-item"><a href="https://jococups.com/reusable-cups/" class="dropdown-item menu-image-title-after menu-image-not-hovered"><img width="200" height="280" src="https://jococups.com/wp-content/uploads/sites/7/2020/01/Joco-Shop-1-ReusableCups-200x280.png" class="menu-image menu-image-title-after" alt="" /><span class="menu-image-title-after menu-image-title">Reusable Cups</span><span></span></a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-24190" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-24190 nav-item"><a href="https://jococups.com/product/20oz-flask-velvet-grip/" class="dropdown-item menu-image-title-after menu-image-not-hovered"><img width="200" height="280" src="https://jococups.com/wp-content/uploads/sites/7/2020/12/Shop-2-Bottles-200x280-1.png" class="menu-image menu-image-title-after" alt="" /><span class="menu-image-title-after menu-image-title">Bottles</span><span></span></a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-100237" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-100237 nav-item"><a href="https://jococups.com/product-category/accessories/straws/" class="dropdown-item menu-image-title-after menu-image-not-hovered"><img width="200" height="280" src="https://jococups.com/wp-content/uploads/sites/7/2019/11/Joco-Shop-6-Straws-200x280.png" class="menu-image menu-image-title-after" alt="" /><span class="menu-image-title-after menu-image-title">Straws</span><span></span></a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-24191" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-24191 nav-item"><a href="https://jococups.com/product-category/glassware/" class="dropdown-item menu-image-title-after menu-image-not-hovered"><img width="200" height="280" src="https://jococups.com/wp-content/uploads/sites/7/2019/08/Joco-Shop-3-Glassware-200x280.png" class="menu-image menu-image-title-after" alt="" /><span class="menu-image-title-after menu-image-title">Glassware</span><span></span></a></li>
	<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-25775" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-25775 nav-item"><a href="https://jococups.com/accessories/" class="dropdown-item menu-image-title-after menu-image-not-hovered"><img width="200" height="280" src="https://jococups.com/wp-content/uploads/sites/7/2019/06/Shop-4-Accessories-200x280.png" class="menu-image menu-image-title-after" alt="" /><span class="menu-image-title-after menu-image-title">Accessories</span><span></span></a></li>
</ul>
</li>

<!--
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-24293" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24293 nav-item"><a href="https://jococups.com/collections/" class="nav-link">Collections<span></span></a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-24064" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24064 nav-item"><a href="https://jococups.com/co-brand/" class="nav-link">Co Brand<span></span></a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-24177" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24177 nav-item"><a href="https://jococups.com/about/our-story/" class="nav-link">About<span></span></a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-107133" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-107133 nav-item"><a href="https://jococups.com/turning-the-tide/" class="nav-link">Impact<span></span></a></li>
<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" id="menu-item-41" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-41 nav-item"><a href="https://jococups.com/journal/" class="nav-link">Why No Plastic<span></span></a></li>
-->

</ul> 
		</div>
		<ul id="right-menu">
			<li><span id="search-icon"></span></li>
			<li>
								<a class="cart-contents" href="https://jococups.com/cart/" title="View your shopping cart">
					<span class="cart-contents-count"></span>				</a>
			</li>
		</ul>
		<div id="mini-cart">
			<div class="cart-header">
				<h3>Cart</h3>
				<p><a href="/shop">Continue Shopping &gt;</a></p>
			</div>
			<div class="widget_shopping_cart_content">

	<p class="woocommerce-mini-cart__empty-message">No products in the cart.</p>


</div>
		</div>
		<div class="overlay"></div>
	</div>		
<!-- homepage slider desktop -->
<div id="homepage-slider" class="flexslider flexslider-desktop">
  	<ul class="slides">
	  		  <li>
		    <img width="2446" height="1058" src="https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility.jpg 2446w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-600x260.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-900x389.jpg 900w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-400x173.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-768x332.jpg 768w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-1536x664.jpg 1536w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-2048x886.jpg 2048w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-24x10.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-36x16.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cup-utility-48x21.jpg 48w" sizes="(max-width: 2446px) 100vw, 2446px" />			<div class="slide-overlay">
				<h2>Joco Cup Utility</h2>
				<p>The master of many, utility meets luxury</p>
			    				  <a href="/reusable-cups/" class="button sandstone"> Shop Utility Cups</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="2446" height="1058" src="https://www.baristainstitute.com/sites/default/files/styles/1x_big_header_image/public/images/header_1.jpg?itok=n_7dW2UI" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw.png 2446w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-600x260.png 600w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-900x389.png 900w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-400x173.png 400w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-768x332.png 768w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-1536x664.png 1536w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-2048x886.png 2048w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-24x10.png 24w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-36x16.png 36w, https://jococups.com/wp-content/uploads/sites/7/2020/10/velvet_grip_straw-48x21.png 48w" sizes="(max-width: 2446px) 100vw, 2446px" />			<div class="slide-overlay">
				<h2>A refined drinking experience</h2>
				<p>The Velvet Grip Straw</p>
			    				  <a href="https://jococups.com/product-category/accessories/straws/" class="button sandstone"> Shop Straws</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="2560" height="1107" src="https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-scaled.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-scaled.jpg 2560w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-600x259.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-900x389.jpg 900w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-400x173.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-768x332.jpg 768w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-1536x664.jpg 1536w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-2048x885.jpg 2048w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-24x10.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-36x16.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBanner-Rollstraw-v2-2880x1245-1-48x21.jpg 48w" sizes="(max-width: 2560px) 100vw, 2560px" />			<div class="slide-overlay">
				<h2>Meet the Roll Straw</h2>
				<p>Rolling conveniently into your everyday</p>
			    				  <a href="/product-category/accessories/straws/" class="button sandstone"> Shop now</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="2560" height="1107" src="https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-scaled.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-scaled.jpg 2560w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-600x259.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-900x389.jpg 900w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-400x173.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-768x332.jpg 768w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-1536x664.jpg 1536w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-2048x885.jpg 2048w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-24x10.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-36x16.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-48x21.jpg 48w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-300x130.jpg 300w, https://jococups.com/wp-content/uploads/sites/7/2019/06/7ZS9yM8A-1024x443.jpg 1024w" sizes="(max-width: 2560px) 100vw, 2560px" />			<div class="slide-overlay">
				<h2>A new form of protest</h2>
				<p>Stop single use waste</p>
			    				  <a href="/product-category/reusable-cups/" class="button sandstone"> Reuse</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="2560" height="1107" src="https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-scaled.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-scaled.jpg 2560w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-600x259.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-900x389.jpg 900w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-400x173.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-768x332.jpg 768w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-1536x664.jpg 1536w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-2048x885.jpg 2048w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-24x10.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-36x16.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-48x21.jpg 48w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-300x130.jpg 300w, https://jococups.com/wp-content/uploads/sites/7/2019/06/onzUDqRg-1-1024x443.jpg 1024w" sizes="(max-width: 2560px) 100vw, 2560px" />			<div class="slide-overlay">
				<h2>Flask-Velvet Grip</h2>
				<p>Hydration solutions for your essential daily ritual</p>
			    				  <a href="/product/20oz-flask-velvet-grip/" class="button sandstone"> Shop now</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="2560" height="1107" src="https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-scaled.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-scaled.jpg 2560w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-600x259.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-900x389.jpg 900w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-400x173.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-768x332.jpg 768w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-1536x664.jpg 1536w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-2048x885.jpg 2048w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-24x10.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-36x16.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-48x21.jpg 48w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-300x130.jpg 300w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-PrecisionSizing-2880x1245-1024x443.jpg 1024w" sizes="(max-width: 2560px) 100vw, 2560px" />			<div class="slide-overlay">
				<h2>Precision sizing</h2>
				<p>Introducing 4oz + 6oz</p>
			    				  <a href="/product-category/reusable-cups/" class="button sandstone"> Shop cups</a>    
			          		</div>
	      </li>
	   	</ul>
</div>
<!-- end homepage slider mobile -->

<!-- homepage slider desktop -->
<div id="homepage-slider" class="flexslider flexslider-mobile">
  	<ul class="slides">
	  		  <li>
		    <img width="640" height="560" src="https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cups-utility-mobile.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cups-utility-mobile.jpg 640w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cups-utility-mobile-600x525.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cups-utility-mobile-400x350.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cups-utility-mobile-24x21.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cups-utility-mobile-36x32.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2020/11/joco-cups-utility-mobile-48x42.jpg 48w" sizes="(max-width: 640px) 100vw, 640px" />			<div class="slide-overlay">
				<h2>Joco Cup Utility</h2>
				<p>The master of many, utility meets luxury</p>
			    				  <a href="/reusable-cups/" class="button sandstone"> Shop Utility Cups</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="640" height="560" src="https://jococups.com/wp-content/uploads/sites/7/2020/10/Velvet_straw_Mobile_banner.png" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2020/10/Velvet_straw_Mobile_banner.png 640w, https://jococups.com/wp-content/uploads/sites/7/2020/10/Velvet_straw_Mobile_banner-600x525.png 600w, https://jococups.com/wp-content/uploads/sites/7/2020/10/Velvet_straw_Mobile_banner-400x350.png 400w, https://jococups.com/wp-content/uploads/sites/7/2020/10/Velvet_straw_Mobile_banner-24x21.png 24w, https://jococups.com/wp-content/uploads/sites/7/2020/10/Velvet_straw_Mobile_banner-36x32.png 36w, https://jococups.com/wp-content/uploads/sites/7/2020/10/Velvet_straw_Mobile_banner-48x42.png 48w" sizes="(max-width: 640px) 100vw, 640px" />			<div class="slide-overlay">
				<h2>A refined drinking experience</h2>
				<p>The Velvet Grip Straw</p>
			    				  <a href="https://jococups.com/product-category/accessories/straws/" class="button sandstone"> Shop Straws</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="590" height="513" src="https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBannerM-Rollstraw-mob-2020.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBannerM-Rollstraw-mob-2020.jpg 590w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBannerM-Rollstraw-mob-2020-400x348.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBannerM-Rollstraw-mob-2020-24x21.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBannerM-Rollstraw-mob-2020-36x31.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2019/12/WebBannerM-Rollstraw-mob-2020-48x42.jpg 48w" sizes="(max-width: 590px) 100vw, 590px" />			<div class="slide-overlay">
				<h2>Meet the Roll Straw</h2>
				<p>Rolling conveniently into your everyday</p>
			    				  <a href="/product-category/accessories/straws/" class="button sandstone"> Shop now</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="640" height="560" src="https://jococups.com/wp-content/uploads/sites/7/2019/06/KGRHUTEw-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2019/06/KGRHUTEw-1.jpg 640w, https://jococups.com/wp-content/uploads/sites/7/2019/06/KGRHUTEw-1-600x525.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2019/06/KGRHUTEw-1-400x350.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2019/06/KGRHUTEw-1-24x21.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2019/06/KGRHUTEw-1-36x32.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2019/06/KGRHUTEw-1-48x42.jpg 48w, https://jococups.com/wp-content/uploads/sites/7/2019/06/KGRHUTEw-1-300x263.jpg 300w" sizes="(max-width: 640px) 100vw, 640px" />			<div class="slide-overlay">
				<h2>A new form of protest</h2>
				<p>Stop single use waste</p>
			    				  <a href="/product-category/reusable-cups/" class="button sandstone"> Reuse</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="640" height="560" src="https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="JOCO Reusable Bottles" srcset="https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1.jpg 640w, https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1-600x525.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1-400x350.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1-24x21.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1-36x32.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1-48x42.jpg 48w, https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1-100x88.jpg 100w, https://jococups.com/wp-content/uploads/sites/7/2019/06/aNFkPbJA-1-300x263.jpg 300w" sizes="(max-width: 640px) 100vw, 640px" />			<div class="slide-overlay">
				<h2>Flask-Velvet Grip</h2>
				<p>Hydration solutions for your essential daily ritual</p>
			    				  <a href="/product/20oz-flask-velvet-grip/" class="button sandstone"> Shop now</a>    
			          		</div>
	      </li>
	   		  <li>
		    <img width="640" height="560" src="https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-M-PrecisionSizing-640x560.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-M-PrecisionSizing-640x560.jpg 640w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-M-PrecisionSizing-640x560-600x525.jpg 600w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-M-PrecisionSizing-640x560-400x350.jpg 400w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-M-PrecisionSizing-640x560-24x21.jpg 24w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-M-PrecisionSizing-640x560-36x32.jpg 36w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-M-PrecisionSizing-640x560-48x42.jpg 48w, https://jococups.com/wp-content/uploads/sites/7/2019/06/Banner-FullWidth-M-PrecisionSizing-640x560-300x263.jpg 300w" sizes="(max-width: 640px) 100vw, 640px" />			<div class="slide-overlay">
				<h2>Precision sizing</h2>
				<p>Introducing 4oz + 6oz</p>
			    				  <a href="/product-category/reusable-cups/" class="button sandstone"> Shop cups</a>    
			          		</div>
	      </li>
	   	</ul>
</div>
<!-- end homepage slider mobile -->


	    	<!-- carousel -->
			<div class="container mobile-scroll-full-width">
				<div class="custom-desktop-scroll">
															
										
					<div class="main-carousel">
					<div class="carousel-cell"><a href="/reusable-cups/"><img src="https://jococups.com/wp-content/uploads/sites/7/2020/01/JOCO-Cup-4oz-Bluestone-Front-Web-1-1.png" /></a><a href="/reusable-cups/"><h3>Reusable Cups</h3></a></div><div class="carousel-cell"><a href="/product/20oz-flask-velvet-grip/"><img src="https://jococups.com/wp-content/uploads/sites/7/2020/12/Joco-Flask-Home.png" /></a><a href="/product/20oz-flask-velvet-grip/"><h3>Glass Bottles</h3></a></div><div class="carousel-cell"><a href="/product-category/accessories/straws/"><img src="https://jococups.com/wp-content/uploads/sites/7/2021/02/Joco-Straw-VelvetGrip-Homepage-Thumb.png" /></a><a href="/product-category/accessories/straws/"><h3>Straws</h3></a></div><div class="carousel-cell"><a href="/product-category/glassware/"><img src="https://jococups.com/wp-content/uploads/sites/7/2021/02/JOCO-HardwareLane-Homepage_thumbnail.png" /></a><a href="/product-category/glassware/"><h3>Glassware</h3></a></div><div class="carousel-cell"><a href="/accessories/"><img src="https://jococups.com/wp-content/uploads/sites/7/2021/02/Joco-Utility-Regular-Homepage-Thumb.png" /></a><a href="/accessories/"><h3>Accessories</h3></a></div>					</div>
										
									</div>
				<div class="custom-mobile-scroll"><div class="glider glider1">	<script>		window.addEventListener("load", function(){			new Glider(document.querySelector(".glider1"), 			{			  slidesToShow: 1,			  slidesToScroll: 1,			  dots: false,			  arrows: false,					  draggable: true,						responsive: 											[                                       					{                                   						breakpoint: 450,                						settings: {                     							slidesToScroll: 1,          							slidesToShow: 2,            							dots: false,                							arrows: false,              							draggable: true,	        						}                               					},                                  					{                                   						breakpoint: 768,                						settings: {                     							slidesToShow: 3,            							slidesToScroll:1.5 ,        							duration: 0.25,             							draggable: true,	        							dots: false,                							arrows: false										}                               					}                                   				]                                       			});                                         		});                                             	</script>                                           <div class="carousel-cell"><a href="/reusable-cups/"><img src="https://jococups.com/wp-content/uploads/sites/7/2020/01/JOCO-Cup-4oz-Bluestone-Front-Web-1-1.png" /></a><a href="Reusable Cups"><h3>Reusable Cups</h3></a></div> <!-- mobile scroller closed--><div class="carousel-cell"><a href="/product/20oz-flask-velvet-grip/"><img src="https://jococups.com/wp-content/uploads/sites/7/2020/12/Joco-Flask-Home.png" /></a><a href="Glass Bottles"><h3>Glass Bottles</h3></a></div> <!-- mobile scroller closed--><div class="carousel-cell"><a href="/product-category/accessories/straws/"><img src="https://jococups.com/wp-content/uploads/sites/7/2021/02/Joco-Straw-VelvetGrip-Homepage-Thumb.png" /></a><a href="Straws"><h3>Straws</h3></a></div> <!-- mobile scroller closed--><div class="carousel-cell"><a href="/product-category/glassware/"><img src="https://jococups.com/wp-content/uploads/sites/7/2021/02/JOCO-HardwareLane-Homepage_thumbnail.png" /></a><a href="Glassware"><h3>Glassware</h3></a></div> <!-- mobile scroller closed--><div class="carousel-cell"><a href="/accessories/"><img src="https://jococups.com/wp-content/uploads/sites/7/2021/02/Joco-Utility-Regular-Homepage-Thumb.png" /></a><a href="Accessories"><h3>Accessories</h3></a></div> <!-- mobile scroller closed--></div><!-- glider closed --></div><!-- mobile scroll closed -->		</div>		
		<!-- end carousel -->
	<div class="full-row testimonial"><div class="container"><h2>Enhanced functionality and sensory experience, </br>overcoming the hazards of plastic</h2><h6>- Joco</h6></div></div><div class="full-row reorder home-video-ttt"><div class="col-sm-12 col-lg-6"><div class="inner"><h2><img src="https://jococups.com/wp-content/themes/jococups/img/turning-the-tide-globet.png" alt="Turning The Tide" /></h2><p> Every Joco purchase serves as a lifetime solution eliminating plastic and single-use waste, with the added means to retrieve and repurpose toxic plastic debris 24/7</p><a href="https://jococups.com/turning-the-tide/" class="button">Learn more</a></div></div><div class="col-sm-12 col-lg-6 last">        <div id="fp609fab6821d84" data-ratio="0.417" data-share="true" class="flowplayer">
            <video autoplay loop>
               <source type="video/mp4" src="https://jococups.com/wp-content/themes/jococups/Joco_TTT2_Website_no_sound_compressed.mp4"/>
            </video>
        </div>
            <style>
        #fp609fab6821d84 {
            max-width: 1440px;max-height: auto;
            background-color: #000;    
        }
    </style></div></div>
</div>
<div id="instagram">
  <div class="container">
  	<h2>Join us and share the message of reuse</h2>
  	<ul id="social-links">
	  	<li><a href="https://instagram.com/jococups" target="_blank">Instagram</a></li>
	  	<li><a href="https://facebook.com/jococups" target="_blank">Facebook</a></li>
  	</ul>
  	
<div id="sb_instagram" class="sbi sbi_col_6  sbi_width_resp sbi_disable_mobile" style="width: 100%;" data-feedid="sbi_jococups#6" data-res="auto" data-cols="6" data-num="6" data-shortcode-atts="{}" >
	
    <div id="sbi_images" >
		<div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_18109510156228866" data-date="1619599590">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/CONBTajBQ5F/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-iad3-2.cdninstagram.com/v/t51.29350-15/178437364_1371796283184067_2926533365055790803_n.jpg?_nc_cat=104&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=Pi7HhiZzv9kAX_fNgZR&#038;_nc_ht=scontent-iad3-2.cdninstagram.com&#038;oh=df3924fec0ed2a8fa743c8975137ac72&#038;oe=60BC14BA" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/178437364_1371796283184067_2926533365055790803_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Pi7HhiZzv9kAX_fNgZR&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=df3924fec0ed2a8fa743c8975137ac72&amp;oe=60BC14BA&quot;,&quot;150&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/178437364_1371796283184067_2926533365055790803_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Pi7HhiZzv9kAX_fNgZR&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=df3924fec0ed2a8fa743c8975137ac72&amp;oe=60BC14BA&quot;,&quot;320&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/178437364_1371796283184067_2926533365055790803_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Pi7HhiZzv9kAX_fNgZR&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=df3924fec0ed2a8fa743c8975137ac72&amp;oe=60BC14BA&quot;,&quot;640&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/178437364_1371796283184067_2926533365055790803_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Pi7HhiZzv9kAX_fNgZR&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=df3924fec0ed2a8fa743c8975137ac72&amp;oe=60BC14BA&quot;}">
            <span class="sbi-screenreader">Small and mighty 🌏</span>
            	                    <img src="https://jococups.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Small and mighty 🌏">
        </a>
    </div>
</div><div class="sbi_item sbi_type_carousel sbi_new sbi_transition" id="sbi_17870187125457656" data-date="1619051988">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/CN8s1cWhWm2/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-iad3-2.cdninstagram.com/v/t51.2885-15/175776639_728515981148661_1260710719337299483_n.jpg?_nc_cat=102&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=vPBop5jXyPsAX_esyQ-&#038;_nc_ht=scontent-iad3-2.cdninstagram.com&#038;oh=54175c61a2e75f587719926418b74a8e&#038;oe=60BC5EEB" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.2885-15\/175776639_728515981148661_1260710719337299483_n.jpg?_nc_cat=102&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=vPBop5jXyPsAX_esyQ-&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=54175c61a2e75f587719926418b74a8e&amp;oe=60BC5EEB&quot;,&quot;150&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.2885-15\/175776639_728515981148661_1260710719337299483_n.jpg?_nc_cat=102&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=vPBop5jXyPsAX_esyQ-&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=54175c61a2e75f587719926418b74a8e&amp;oe=60BC5EEB&quot;,&quot;320&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.2885-15\/175776639_728515981148661_1260710719337299483_n.jpg?_nc_cat=102&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=vPBop5jXyPsAX_esyQ-&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=54175c61a2e75f587719926418b74a8e&amp;oe=60BC5EEB&quot;,&quot;640&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.2885-15\/175776639_728515981148661_1260710719337299483_n.jpg?_nc_cat=102&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=vPBop5jXyPsAX_esyQ-&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=54175c61a2e75f587719926418b74a8e&amp;oe=60BC5EEB&quot;}">
            <span class="sbi-screenreader">Stopping the plastic flow, harvesting the pollutio</span>
            <svg class="svg-inline--fa fa-clone fa-w-16 sbi_lightbox_carousel_icon" aria-hidden="true" aria-label="Clone" data-fa-proƒcessed="" data-prefix="far" data-icon="clone" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
	                <path fill="currentColor" d="M464 0H144c-26.51 0-48 21.49-48 48v48H48c-26.51 0-48 21.49-48 48v320c0 26.51 21.49 48 48 48h320c26.51 0 48-21.49 48-48v-48h48c26.51 0 48-21.49 48-48V48c0-26.51-21.49-48-48-48zM362 464H54a6 6 0 0 1-6-6V150a6 6 0 0 1 6-6h42v224c0 26.51 21.49 48 48 48h224v42a6 6 0 0 1-6 6zm96-96H150a6 6 0 0 1-6-6V54a6 6 0 0 1 6-6h308a6 6 0 0 1 6 6v308a6 6 0 0 1-6 6z"></path>
	            </svg>	                    <img src="https://jococups.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Stopping the plastic flow, harvesting the pollution. This pair tackles the plastic problem on separate fronts, but also collectively via the Joco x Seabin Project Fleet which is funded by every Joco purchase. For maximum positive impact, powered by the individual. 👉🏽

#earthday  #earthdayeveryday  #jococups @seabin_project">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17898750646913548" data-date="1618186149">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/CNi5YPEhnhR/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-iad3-2.cdninstagram.com/v/t51.29350-15/172085207_1592164557659926_4324393984438817089_n.jpg?_nc_cat=108&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=2UW__9txXnQAX-TjF2w&#038;_nc_ht=scontent-iad3-2.cdninstagram.com&#038;oh=319dd459b7ba87ade3ea76e5c3883219&#038;oe=60BD1687" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/172085207_1592164557659926_4324393984438817089_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=2UW__9txXnQAX-TjF2w&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=319dd459b7ba87ade3ea76e5c3883219&amp;oe=60BD1687&quot;,&quot;150&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/172085207_1592164557659926_4324393984438817089_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=2UW__9txXnQAX-TjF2w&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=319dd459b7ba87ade3ea76e5c3883219&amp;oe=60BD1687&quot;,&quot;320&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/172085207_1592164557659926_4324393984438817089_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=2UW__9txXnQAX-TjF2w&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=319dd459b7ba87ade3ea76e5c3883219&amp;oe=60BD1687&quot;,&quot;640&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/172085207_1592164557659926_4324393984438817089_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=2UW__9txXnQAX-TjF2w&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=319dd459b7ba87ade3ea76e5c3883219&amp;oe=60BD1687&quot;}">
            <span class="sbi-screenreader">Inspiration from a pre-pandemic capture ✨ via @l</span>
            	                    <img src="https://jococups.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Inspiration from a pre-pandemic capture ✨ via @lamyrtille">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_18108117115213419" data-date="1616635685">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/CM0sGhuB3Cn/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-iad3-2.cdninstagram.com/v/t51.29350-15/163792946_1098512360631556_975291582155797009_n.jpg?_nc_cat=108&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=t3BdHDV_JI4AX_4eXgC&#038;_nc_ht=scontent-iad3-2.cdninstagram.com&#038;oh=e3cd056a7e88dc79b056d49c76255210&#038;oe=60BB7C97" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/163792946_1098512360631556_975291582155797009_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=t3BdHDV_JI4AX_4eXgC&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=e3cd056a7e88dc79b056d49c76255210&amp;oe=60BB7C97&quot;,&quot;150&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/163792946_1098512360631556_975291582155797009_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=t3BdHDV_JI4AX_4eXgC&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=e3cd056a7e88dc79b056d49c76255210&amp;oe=60BB7C97&quot;,&quot;320&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/163792946_1098512360631556_975291582155797009_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=t3BdHDV_JI4AX_4eXgC&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=e3cd056a7e88dc79b056d49c76255210&amp;oe=60BB7C97&quot;,&quot;640&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/163792946_1098512360631556_975291582155797009_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=t3BdHDV_JI4AX_4eXgC&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=e3cd056a7e88dc79b056d49c76255210&amp;oe=60BB7C97&quot;}">
            <span class="sbi-screenreader">Whether on the move or sipping leisurely, the Joco</span>
            	                    <img src="https://jococups.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Whether on the move or sipping leisurely, the Joco Cup-Classic incorporates the materials &amp; function to enhance your daily ritual.

#theoriginal #plasticfree">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17868571337342939" data-date="1615760898">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/CManlEIB2Dn/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-iad3-2.cdninstagram.com/v/t51.29350-15/159914852_920142382136204_1673266503173061349_n.jpg?_nc_cat=102&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=R1KG2EdPzsUAX_2KC8h&#038;_nc_ht=scontent-iad3-2.cdninstagram.com&#038;oh=c88f1d306e46a1dc929f8474cf43d06b&#038;oe=60BDD2BF" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/159914852_920142382136204_1673266503173061349_n.jpg?_nc_cat=102&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=R1KG2EdPzsUAX_2KC8h&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=c88f1d306e46a1dc929f8474cf43d06b&amp;oe=60BDD2BF&quot;,&quot;150&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/159914852_920142382136204_1673266503173061349_n.jpg?_nc_cat=102&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=R1KG2EdPzsUAX_2KC8h&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=c88f1d306e46a1dc929f8474cf43d06b&amp;oe=60BDD2BF&quot;,&quot;320&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/159914852_920142382136204_1673266503173061349_n.jpg?_nc_cat=102&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=R1KG2EdPzsUAX_2KC8h&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=c88f1d306e46a1dc929f8474cf43d06b&amp;oe=60BDD2BF&quot;,&quot;640&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/159914852_920142382136204_1673266503173061349_n.jpg?_nc_cat=102&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=R1KG2EdPzsUAX_2KC8h&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=c88f1d306e46a1dc929f8474cf43d06b&amp;oe=60BDD2BF&quot;}">
            <span class="sbi-screenreader">A personal vessel = personal protection. Keep in t</span>
            	                    <img src="https://jococups.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="A personal vessel = personal protection. Keep in the know of what you’re exposed to.

#health #contactlesspour">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17911042429652876" data-date="1615157236">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/CMIoL5KBrgL/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent-iad3-2.cdninstagram.com/v/t51.29350-15/158227416_2945345659069763_4958349030801155102_n.jpg?_nc_cat=106&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=VHBE36-1qQoAX-hsfzs&#038;_nc_ht=scontent-iad3-2.cdninstagram.com&#038;oh=ebd8b32d652e4201a8f89bd74c6ccbaa&#038;oe=60BCE63D" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/158227416_2945345659069763_4958349030801155102_n.jpg?_nc_cat=106&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=VHBE36-1qQoAX-hsfzs&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=ebd8b32d652e4201a8f89bd74c6ccbaa&amp;oe=60BCE63D&quot;,&quot;150&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/158227416_2945345659069763_4958349030801155102_n.jpg?_nc_cat=106&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=VHBE36-1qQoAX-hsfzs&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=ebd8b32d652e4201a8f89bd74c6ccbaa&amp;oe=60BCE63D&quot;,&quot;320&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/158227416_2945345659069763_4958349030801155102_n.jpg?_nc_cat=106&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=VHBE36-1qQoAX-hsfzs&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=ebd8b32d652e4201a8f89bd74c6ccbaa&amp;oe=60BCE63D&quot;,&quot;640&quot;:&quot;https:\/\/scontent-iad3-2.cdninstagram.com\/v\/t51.29350-15\/158227416_2945345659069763_4958349030801155102_n.jpg?_nc_cat=106&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=VHBE36-1qQoAX-hsfzs&amp;_nc_ht=scontent-iad3-2.cdninstagram.com&amp;oh=ebd8b32d652e4201a8f89bd74c6ccbaa&amp;oe=60BCE63D&quot;}">
            <span class="sbi-screenreader">Sip it quicker, sip it thicker. Joco Cup-Utility f</span>
            	                    <img src="https://jococups.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Sip it quicker, sip it thicker. Joco Cup-Utility ft. Flow Control">
        </a>
    </div>
</div>    </div>

	<div id="sbi_load">

	
	
</div>
	    <span class="sbi_resized_image_data" data-feed-id="sbi_jococups#6" data-resized="{&quot;18108117115213419&quot;:{&quot;id&quot;:&quot;163792946_1098512360631556_975291582155797009_n&quot;,&quot;ratio&quot;:&quot;1.00&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17868571337342939&quot;:{&quot;id&quot;:&quot;159914852_920142382136204_1673266503173061349_n&quot;,&quot;ratio&quot;:&quot;0.80&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17911042429652876&quot;:{&quot;id&quot;:&quot;158227416_2945345659069763_4958349030801155102_n&quot;,&quot;ratio&quot;:&quot;0.80&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17898750646913548&quot;:{&quot;id&quot;:&quot;172085207_1592164557659926_4324393984438817089_n&quot;,&quot;ratio&quot;:&quot;0.80&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17870187125457656&quot;:{&quot;id&quot;:&quot;175776639_728515981148661_1260710719337299483_n&quot;,&quot;ratio&quot;:&quot;0.80&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;18109510156228866&quot;:{&quot;id&quot;:&quot;178437364_1371796283184067_2926533365055790803_n&quot;,&quot;ratio&quot;:&quot;0.80&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}}}">
	</span>
	</div>

<script type="text/javascript">var sb_instagram_js_options = {"font_method":"svg","placeholder":"https:\/\/jococups.com\/wp-content\/plugins\/instagram-feed\/img\/placeholder.png","resized_url":"https:\/\/jococups.com\/wp-content\/uploads\/sites\/7\/sb-instagram-feed-images\/"};</script><script type='text/javascript' src='https://jococups.com/wp-content/plugins/instagram-feed/js/sbi-scripts.min.js?ver=2.5.3'></script>  </div>
</div>
<div id="newsletter">
  <div class="container">
	  <p>Keep informed on new releases and subscriber exclusives</p>
	  	  <div class="mailchimp-form" >
			<style>
				div#mce-success-response,div#mce-error-response {
					background: #373737;
					padding: 8px;
					margin-top: 10px;
					color: #f7eee5;
					font-family: 'museo-sans';
				}
				.mc-field-group {
					font-family: 'museo-sans';
				}
				div#mce-error-response 
				{
					background-color: #6B0505; 
					color: #fff;
				}
				input#mc-embedded-subscribe {
					margin-top: -22px;
				}
				div#mce-error-response a {
					color: #FFF;
				}
			</style>
			<!-- Begin Mailchimp Signup Form -->
			<div id="mc_embed_signup">
				<form action="https://jococups.us16.list-manage.com/subscribe/post?u=d97fe21b9f5ee493c68e5b3bc&amp;id=5649ef46f8" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
					<div id="mc_embed_signup_scroll">					
						<div class="mc-field-group">
							<input type="email" value="" name="EMAIL" class="required email es_required_field es_txt_email" id="mce-EMAIL" placeholder="Email Address"	>
						</div>
							<div id="mce-responses" class="clear">
								<div class="response" id="mce-error-response" style="display:none"></div>
								<div class="response" id="mce-success-response" style="display:none"></div>
							</div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
							<div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_d97fe21b9f5ee493c68e5b3bc_5649ef46f8" tabindex="-1" value=""></div>
							<div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
					</div>
				</form>
			</div>
			<script type='text/javascript' src='//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js'></script><script type='text/javascript'>(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';fnames[3]='ADDRESS';ftypes[3]='address';fnames[4]='PHONE';ftypes[4]='phone';}(jQuery));var $mcj = jQuery.noConflict(true);</script>
			<!--End mc_embed_signup-->
	  </div>
	 <!-- <form>
		  <input id="email-address" type="text" placeholder="Email address">
		  <input id="submit" type="submit" value="submit">
	  </form>-->
  </div>
</div>
<div id="footer">
  <div class="container">
	<div id="nav_menu-2" class="widget widget_nav_menu"><h3 class="widget-title">Customer Care</h3><div class="menu-customer-care-container"><ul id="menu-customer-care" class="menu"><li id="menu-item-55" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-55"><a href="https://jococups.com/customer-care/contact-us/">Contact Us</a></li>
<li id="menu-item-57" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-57"><a href="https://jococups.com/customer-care/faqs/">FAQs</a></li>
<li id="menu-item-24365" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24365"><a href="https://jococups.com/customer-care/product-support/">Product Support</a></li>
<li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-60"><a href="https://jococups.com/customer-care/terms-conditions/">Terms &#038; Conditions</a></li>
<li id="menu-item-56" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-56"><a href="https://jococups.com/customer-care/delivery-returns/">Delivery &#038; Returns</a></li>
<li id="menu-item-24368" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24368"><a href="https://jococups.com/customer-care/warranty/">Warranty</a></li>
<li id="menu-item-109020" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-109020"><a href="https://jococups.com/customer-care/find-in-store/">Find in store</a></li>
<li id="menu-item-59" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-59"><a href="https://jococups.com/customer-care/privacy-policy/">Privacy Policy</a></li>
</ul></div></div>	<div id="nav_menu-3" class="widget widget_nav_menu"><h3 class="widget-title">About</h3><div class="menu-about-container"><ul id="menu-about" class="menu"><li id="menu-item-74" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-74"><a href="https://jococups.com/about/our-story/">Our story</a></li>
<li id="menu-item-24375" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24375"><a href="https://jococups.com/about/barista-tips/">Barista Tips</a></li>
<li id="menu-item-71" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-71"><a href="https://jococups.com/about/know-your-size/">Know your size</a></li>
<li id="menu-item-109021" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-109021"><a href="https://jococups.com/customer-care/find-in-store/">Find in store</a></li>
<li id="menu-item-26667" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26667"><a href="https://jococups.com/innovation-ip/">Intellectual Property</a></li>
<li id="menu-item-100980" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-100980"><a href="https://jococups.com/eco-centre/">Eco Centre</a></li>
</ul></div></div>  </div>
</div>
<!-- Instagram Feed JS -->
<script type="text/javascript">
var sbiajaxurl = "https://jococups.com/wp-admin/admin-ajax.php";
</script>

<!-- Facebook Pixel Code -->
<noscript>
<img height="1" width="1" style="display:none" alt="fbpx"
src="https://www.facebook.com/tr?id=1028530147350810&ev=PageView&noscript=1"/>
</noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->
    <div id="jilt-cart-data" style="display: none !important;" data-nosnippet>{&quot;cart_token&quot;:&quot;&quot;,&quot;hash&quot;:&quot;&quot;,&quot;cart_data&quot;:&quot;&quot;}</div>	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript'>
window.FPConfig= {
	delay: 0,
	ignoreKeywords: ["\/wp-admin","\/wp-login.php","\/cart","\/checkout","add-to-cart","logout","#","?",".png",".jpeg",".jpg",".gif",".svg",".webp"],
	maxRPS: 3,
    hoverDelay: 50
};
</script>
<script type='text/javascript' src='https://jococups.com/wp-content/plugins/flying-pages/flying-pages.min.js?ver=2.4.2' defer></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_additional_variation_images_local = {"ajax_url":"\/?wc-ajax=%%endpoint%%","ajaxImageSwapNonce":"24cb1efb23","gallery_images_class":".product .images .flex-control-nav, .product .images .thumbnails","main_images_class":".woocommerce-product-gallery","lightbox_images":".product .images a.zoom","custom_swap":"","custom_original_swap":"","custom_reset_swap":"","bwc":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://jococups.com/wp-content/plugins/woocommerce-additional-variation-images/assets/js/variation-images-frontend.min.js?ver=1.7.15'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_swatches_params = {"ajax_url":"https:\/\/jococups.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://jococups.com/wp-content/plugins/woocommerce-variation-swatches-and-photos/assets/js/swatches-and-photos.js?ver=1.5.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mailchimp_public_data = {"site_url":"https:\/\/jococups.com","ajax_url":"https:\/\/jococups.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='https://jococups.com/wp-content/plugins/mailchimp-for-woocommerce/public/js/mailchimp-woocommerce-public.min.js?ver=2.3'></script>
<script type='text/javascript' src='https://jococups.com/wp-content/plugins/woocommerce/assets/js/flexslider/jquery.flexslider.min.js?ver=2.7.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var jiltStorefrontParams = {"public_key":"pk_8d9daaa0499b50fd09ff6f1f7914cedc","order_address_mapping":{"email":"email","first_name":"first_name","last_name":"last_name","address_1":"address1","address_2":"address2","company":"company","city":"city","state":"state_code","postcode":"postal_code","country":"country_code","phone":"phone"},"cart_hash":"81bb4fbc442af1750532691c933604a2","cart_token":"86c0c74e-b6ba-4074-bfe2-4235c9b5cd21","ajax_url":"\/?wc-ajax=%%endpoint%%","nonce":"e361926554","log_threshold":"100","x_jilt_shop_domain":"jococups.com","shop_uuid":"40b20d95-e824-4bc7-90eb-14ab96504361","show_email_usage_notice":"","popover_dismiss_message":"No thanks, I'll enter my email later.","platform":"woocommerce","api_url":"https:\/\/api.jilt.com","tracking_elem_selector":"#jilt-cart-data","signup_form":null,"capture_email_on_add_to_cart":"1","recover_held_orders":"","show_marketing_consent_opt_in":"","checkout_consent_prompt":"Please send me emails with exclusive offers and other updates from JOCO Cups. Unsubscribe at any time and see our Privacy Policy for how we use your data.","add_to_cart_title":"Reserve this item in your cart!"};
/* ]]> */
</script>
<script type='text/javascript' src='https://js.jilt.com/storefront/v1/jilt.js?ver=1.7.8'></script>
<script type='text/javascript' src='https://jococups.com/wp-includes/js/wp-embed.min.js?ver=5.3.8'></script>
<!-- WooCommerce JavaScript -->
<script type="text/javascript">
jQuery(function($) { 

			$( '.add_to_cart_button:not(.product_type_variable, .product_type_grouped)' ).click( function() {
				ga('send', 'event', 'Products', 'Add to Cart', ($(this).data('product_sku')) ? ($(this).data('product_sku')) : ('#' + $(this).data('product_id')));
			});
		
 });
</script>
</div>
</body>
</html>